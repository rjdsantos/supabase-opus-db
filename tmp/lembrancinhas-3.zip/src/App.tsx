import { EventDetailsView } from "./components/EventDetailsView";

// Dados do formulário baseados na imagem fornecida
const sampleEventData = {
  dataEspecial: "24/09/2025",
  estiloAguaTorna: false,
  estiloClassico: false,
  estiloDocesDecorados: false,
  estiloEscaldaPe: true,
  estiloMandala: false,
  estiloUltraPerfumado: false,
  estiloUltraSuave: false,
  estiloUltraSuaveTanto: "Não informado",
  estiloPeleOleosaLrol: false,
  estiloSabonetes: false,
  estiloVelaPersonalizada: false,
  incluirPresentesEspeciais: true, // Mudei para true para demonstrar o destaque
  quantidade: 1,
  temaOuDecorado: "asd",
  tipoEvento: "batizado"
};

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <EventDetailsView eventData={sampleEventData} />
    </div>
  );
}