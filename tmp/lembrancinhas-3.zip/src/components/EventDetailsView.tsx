import { Calendar } from "./ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { CalendarDays, Users, Sparkles, Gift } from "lucide-react";

interface EventData {
  dataEspecial: string;
  estiloAguaTorna: boolean;
  estiloClassico: boolean;
  estiloDocesDecorados: boolean;
  estiloEscaldaPe: boolean;
  estiloMandala: boolean;
  estiloUltraPerfumado: boolean;
  estiloUltraSuave: boolean;
  estiloUltraSuaveTanto: string;
  estiloPeleOleosaLrol: boolean;
  estiloSabonetes: boolean;
  estiloVelaPersonalizada: boolean;
  incluirPresentesEspeciais: boolean;
  quantidade: number;
  temaOuDecorado: string;
  tipoEvento: string;
}

interface EventDetailsViewProps {
  eventData: EventData;
}

export function EventDetailsView({ eventData }: EventDetailsViewProps) {
  // Parse da data do evento
  const [day, month, year] = eventData.dataEspecial.split('/').map(Number);
  const eventDate = new Date(year, month - 1, day);
  
  // Formatação da data com dia da semana
  const dateFormatter = new Intl.DateTimeFormat('pt-BR', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  // Filtragem dos estilos que são true
  const selectedStyles = [];
  if (eventData.estiloAguaTorna) selectedStyles.push('Água torna');
  if (eventData.estiloClassico) selectedStyles.push('Clássico');
  if (eventData.estiloDocesDecorados) selectedStyles.push('Doces decorados');
  if (eventData.estiloEscaldaPe) selectedStyles.push('Escalda pé');
  if (eventData.estiloMandala) selectedStyles.push('Mandala');
  if (eventData.estiloUltraPerfumado) selectedStyles.push('Ultra perfumado');
  if (eventData.estiloUltraSuave) selectedStyles.push('Ultra suave');
  if (eventData.estiloPeleOleosaLrol) selectedStyles.push('Pele oleosa');
  if (eventData.estiloSabonetes) selectedStyles.push('Sabonetes');
  if (eventData.estiloVelaPersonalizada) selectedStyles.push('Vela personalizada');

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header com Tipo de Evento */}
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2 capitalize">
            <Sparkles className="h-6 w-6 text-blue-500" />
            {eventData.tipoEvento}
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Calendário com Data do Evento */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarDays className="h-5 w-5" />
              Data Especial
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-center">
              <Calendar
                mode="single"
                selected={eventDate}
                disabled={false}
                className="rounded-md border"
              />
            </div>
            <div className="text-center">
              <p className="capitalize">
                {dateFormatter.format(eventDate)}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Informações do Evento */}
        <div className="space-y-6">
          {/* Quantidade */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Quantidade
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <span className="text-3xl font-bold text-primary">
                  {eventData.quantidade}
                </span>
                <p className="text-muted-foreground">unidade(s)</p>
              </div>
            </CardContent>
          </Card>

          {/* Presentes Especiais - Destaque especial quando true */}
          {eventData.incluirPresentesEspeciais && (
            <Card className="border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-amber-700 dark:text-amber-300">
                  <Gift className="h-5 w-5" />
                  Presentes Especiais
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-amber-500 rounded-full animate-pulse"></div>
                  <p className="text-amber-700 dark:text-amber-300">
                    Incluído no orçamento
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Estilos Selecionados */}
          {selectedStyles.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Estilos Selecionados</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {selectedStyles.map((style, index) => (
                    <Badge key={index} variant="secondary" className="px-3 py-1">
                      {style}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Separador */}
      <Separator className="my-8" />

      {/* Descrição do Evento - Sempre ao final */}
      <Card>
        <CardHeader>
          <CardTitle>Tema ou Decorado</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground leading-relaxed">
            {eventData.temaOuDecorado}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}