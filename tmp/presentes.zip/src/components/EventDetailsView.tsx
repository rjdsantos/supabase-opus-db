import { Calendar } from "./ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { CalendarDays, Gift, PackageOpen } from "lucide-react";

interface EventData {
  dataEntrega: string;
  orientacoesAdicionais: string;
  tipoPresente: string;
}

interface EventDetailsViewProps {
  eventData: EventData;
}

export function EventDetailsView({ eventData }: EventDetailsViewProps) {
  // Parse da data de entrega
  const [day, month, year] = eventData.dataEntrega.split('/').map(Number);
  const deliveryDate = new Date(year, month - 1, day);
  
  // Formatação da data com dia da semana
  const dateFormatter = new Intl.DateTimeFormat('pt-BR', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  // Formatação do tipo de presente para exibição
  const formatTipoPresente = (tipo: string) => {
    return tipo
      .replace(/_/g, ' ')
      .replace(/\b\w/g, l => l.toUpperCase());
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header com Título */}
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2">
            <Gift className="h-6 w-6 text-purple-500" />
            Detalhes do Seu Orçamento
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Calendário com Data de Entrega */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarDays className="h-5 w-5" />
              Data Entrega
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-center">
              <Calendar
                mode="single"
                selected={deliveryDate}
                disabled={false}
                className="rounded-md border"
              />
            </div>
            <div className="text-center">
              <p className="capitalize">
                {dateFormatter.format(deliveryDate)}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Informações do Presente */}
        <div className="space-y-6">
          {/* Tipo de Presente */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PackageOpen className="h-5 w-5" />
                Tipo de Presente
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <Badge variant="default" className="px-4 py-2 text-base">
                  {formatTipoPresente(eventData.tipoPresente)}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Separador */}
      <Separator className="my-8" />

      {/* Orientações Adicionais - Sempre ao final */}
      <Card>
        <CardHeader>
          <CardTitle>Orientações Adicionais</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground leading-relaxed">
            {eventData.orientacoesAdicionais}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}