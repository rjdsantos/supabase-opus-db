import { EventDetailsView } from "./components/EventDetailsView";

// Dados do formulário baseados na imagem fornecida
const sampleEventData = {
  dataEntrega: "19/11/2025",
  orientacoesAdicionais: "bla bla bla",
  tipoPresente: "kit_criativo_infantil"
};

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <EventDetailsView eventData={sampleEventData} />
    </div>
  );
}